import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import axios from 'axios';
import { methods } from "express";
import { useState } from 'react';

export default function App() {

  const [variants, setVariants] = useState({});

 async function subitImage(){

const formData = new FormData();

formData.append("file", image);

 const {data}= await axios.request({
 url:"https://api.cloudflare.com/client/v4/accounts/ca9b43f77ee269734e8818fd05c17671/images/v1",
 method: "POST",
 data: formData,
 headers:{
  "Authorization": "Bearer  SryB0ILgY7SpKAERbG5_Z9FKqpUXux7EQ3APsDlM"
 }

})
 
}

{
  "result"; {
      "id"; "6978a8bb-1211-418e-87dd-db1bfa3e1900",
      "filename"; "Captura de pantalla 2024-02-20 210330.png",
      "uploaded"; "2024-02-25T23:40:03.879Z",
      "requireSignedURLs"; false
      "variants"; [
          "https://imagedelivery.net/Bvr5hrAFVw2Nz4XVu7IbZA/6978a8bb-1211-418e-87dd-db1bfa3e1900/icon",
          "https://imagedelivery.net/Bvr5hrAFVw2Nz4XVu7IbZA/6978a8bb-1211-418e-87dd-db1bfa3e1900/small",
          "https://imagedelivery.net/Bvr5hrAFVw2Nz4XVu7IbZA/6978a8bb-1211-418e-87dd-db1bfa3e1900/public",
          "https://imagedelivery.net/Bvr5hrAFVw2Nz4XVu7IbZA/6978a8bb-1211-418e-87dd-db1bfa3e1900/profile"
      ]
  };
  "success"; true,
  "errors"; [],
  "messages"; []
}};